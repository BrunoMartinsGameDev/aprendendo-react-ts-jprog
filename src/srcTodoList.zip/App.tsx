import './App.css'
import TodoApp from './components/to_do_app/ToDoApp'

function App() {

  return (
    <>
      <TodoApp />
    </>
  )
}

export default App
